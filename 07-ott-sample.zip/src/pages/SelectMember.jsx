import React from 'react'

export const SelectMember = () => {
    return (
        <section className='sub-page pt-25'>
            <div className="inner">
                <h2 className="section-title text-3xl font-b택ld">멤버선택</h2>
            </div>
        </section>
    )
}
