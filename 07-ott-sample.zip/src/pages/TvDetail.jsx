import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useMovieStore } from '../store/useMovieStore';

export const TvDetail = () => {
  // 주소의 TV 프로그램 ID
  const { id } = useParams();
  const tvId = Number(id);

  // 팝업 상태
  const [showPopup, setShowPopup] = useState(false);

  const handlePopup = () => {
    setShowPopup(true);
  };

  const handleClose = () => {
    setShowPopup(false);
  };

  // Zustand 스토어
  const { tvs, tvVideo, onFetchTv, onFetchTvVideo } =
    useMovieStore();

  // TV 목록에서 해당 프로그램 찾기
  const tv = tvs.find((item) => item.id === tvId);

  // TV 목록이 없으면 불러오기
  useEffect(() => {
    if (tvs.length === 0) {
      onFetchTv();
    }
  }, [tvs.length, onFetchTv]);

  // 해당 TV 프로그램 영상 가져오기
  useEffect(() => {
    if (tvId) {
      onFetchTvVideo(tvId);
    }
  }, [tvId, onFetchTvVideo]);

  // 영상 정보
  const video = tvVideo[tvId];

  // 예고편 찾기
  const trailer = video?.find(
    (v) =>
      v.site === 'YouTube' &&
      (v.type === 'Trailer' || v.type === 'Teaser')
  );

  return (
    <section className="sub-page py-30">
      <div className="inner flex gap-15">
        {/* TV 포스터 */}
        <div className="w-2/6">
          <img
            src={
              tv?.poster_path
                ? `https://image.tmdb.org/t/p/w500${tv.poster_path}`
                : '/images/no-image.png'
            }
            alt={tv?.name || 'TV 포스터'}
          />
        </div>

        {/* TV 정보 */}
        <div className="w-4/6">
          <h2 className="text-5xl">
            {tv?.name || 'TV 프로그램'}
          </h2>

          <p>평점: {tv?.vote_average?.toFixed(1)}</p>

          <p className="my-10">
            {tv?.overview || '프로그램 소개가 없습니다.'}
          </p>

          <div className="flex gap-5">
            <button
              className="bg-black text-white p-4"
              onClick={handlePopup}
              disabled={!trailer}
            >
              재생하기
            </button>

            <button className="border p-4">
              찜하기
            </button>
          </div>
        </div>
      </div>

      {/* 예고편 팝업 */}
      {showPopup && trailer && (
        <div className="fixed inset-0 bg-black w-full h-full z-[10000]">
          <button
            onClick={handleClose}
            className="absolute right-5 top-5 bg-white p-2 z-10"
          >
            닫기
          </button>

          <iframe
            className="w-full h-full"
            src={`https://www.youtube.com/embed/${trailer.key}?autoplay=1`}
            title={`${tv?.name} 예고편`}
            allow="autoplay; encrypted-media"
            allowFullScreen
          />
        </div>
      )}
    </section>
  );
};
