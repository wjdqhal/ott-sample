import { create } from "zustand";

//TMDB키를 변수로 저장하기
const TMDB_KEY = import.meta.env.VITE_TMDB_API_KEY;

export const useMovieStore = create((set, get) => ({
    // #######영화(인기)
    //인기영화를 저장할 배열
    popMovies: [],
    //인기영화를 불러올 메서드
    onFetchPopular: async () => {
        const res = await fetch(`https://api.themoviedb.org/3/movie/popular?api_key=${TMDB_KEY}&language=ko-KR&page=1`)
        // console.log(res);
        const data = await res.json();
        // console.log(data);
        set({ popMovies: data.results })
    },
    //영화의 비디오를 저장할 변수
    popVideo: {},
    //영화의 비디오를 불러오는 메서드
    onFetchVideo: async (id) => {
        //기존에 불러온 영상이 있는지를 체크해서 있으면 스톱
        const { popVideo } = get();
        if (popVideo[id]) return;

        const res = await fetch(`https://api.themoviedb.org/3/movie/${id}/videos?api_key=${TMDB_KEY}&language=ko-KR`)
        // console.log("비디오", res)
        const data = await res.json();
        // console.log("비디오 데이터", data)
        set((state) => ({
            popVideo: {
                ...state.popVideo,
                [id]: data.results
            }
        }))
    },


    // #########티비 (인기)
    // 인기 티비 프로그램을 저장할 배열
    tvs: [],
    // 인기 티비 프로그램의 영상을 저장할 오브젝트
    tvVideo: {},
    // 인기 티비 프로그램을 불러올 메서드
    onFetchTv: async () => {
        const res = await fetch(`https://api.themoviedb.org/3/tv/popular?api_key=${TMDB_KEY}&language=ko-KR&page=1`)
        const data = await res.json();
        console.log("인기티비", data);
        set({ tvs: data.results })
    },
    // 인기 티비 프로그램의 영상을 불러올 메서드
    onFetchTvVideo: async (id) => {
        const { tvVideo } = get();
        if (tvVideo[id]) return;

        const res = await fetch(`https://api.themoviedb.org/3/tv/${id}/videos?api_key=${TMDB_KEY}&language=en-US&page=1`)
        const data = await res.json();

        set((state) => ({
            tvVideo: {
                ...state.tvVideo,
                [id]: data.results
            }
        }))
    },
    // 시즌
    seasons: [],
    onFetchSeason: async (id) => {

    },
    // 시즌별 에피소드
    episodes: [],
    onFetchEpisode: async (id, season) => { }

}))